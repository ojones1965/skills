---
name: app-discovery-whitepaper
description: 'Explore an unfamiliar web application (source code + optionally a live deployed instance), tour every page/tab in a real browser, save full-page screenshots, and produce a structured white paper or a timed video script grounded in that documentation. USE FOR: "document this app", "write a white paper", "explain what this application does", "capture screenshots of the app", "tour the live app and document it", "generate app documentation with screenshots", "create a video script from the white paper", "turn this app documentation into a narrated demo". Applies to any repo + optional live URL (Databricks Apps, Azure Web Apps, internal dashboards, etc).'
---

# App Discovery & White Paper Generation

Turns an unfamiliar codebase (and, if available, its live deployed instance) into
a screenshot-illustrated white paper describing what it does, who uses it, and
how it's built. It can also transform the completed white paper and screenshot
set into a production-ready narrated video script.

## When to Use
- User asks to document/explain an application you haven't seen before.
- User wants a white paper, functionality summary, or user guide with real screenshots.
- User provides a live app URL and wants it "shown working" or toured.
- User wants a video script, narrated demo, storyboard, or voiceover based on
  an existing app white paper and screenshot set. For the rendered MP4 itself,
  hand off to `narrated-demo-video` (step 8).
- User says "there are pages missing" after a first pass — usually means you
  documented the wrong artifact (see Pitfall 1 below) and need to re-tour the
  real live app.

## Procedure

### 1. Read source before touching a browser
Grep/read in this order to build a mental model fast:
- `README.md`, any `HANDOFF-*.md` / `docs/*.md` — stated purpose, owner, status.
- Backend entrypoint (`main.py`, `app.py`, `server.js`, etc.) — every route,
  auth mechanism, data source (tables, DBs, warehouses).
- Frontend entry (`App.tsx`/`App.vue`/etc.) — page/tab list, nav structure,
  which pages are gated (admin-only, feature-flagged).
- Deploy config (`app.yaml`, `azure.yaml`, `deploy.py`, Dockerfile) — this is
  where the **live URL or hosting target** is usually declared or implied.

Do this with parallel `read_file`/`grep_search` calls, not one file at a time.

### 2. Determine whether a live instance exists and should be used
If the user gives you a live URL, or one is discoverable in deploy config,
**prefer touring the live app over a locally-served static build** — the repo
checked out locally can be stale, mismatched, or even a completely different
application than what's actually deployed at that URL (this has happened —
see Pitfall 1). Confirm the live app's title/branding matches expectations
before writing anything about it.

### 3. Get into the live app
- Open it with the browser tool. If it redirects to an SSO/login page, **do
  not attempt to authenticate for the user** — ask them (via the
  ask-questions tool) to complete login in the shared tab, then continue.
  Never route secrets/credentials through any tool.
- If no live app is reachable (no network access, no credentials, sandboxed
  environment) fall back to serving the compiled frontend locally:
  - Find the production build output folder (e.g. `static/`, `dist/`, `build/`).
  - Check `index.html` for asset paths (e.g. `/static/assets/...`). Serve from
    the **parent** directory of that build folder, not the build folder
    itself, so absolute asset paths resolve (`npx serve -l <port> <parent>`).
    Getting this wrong yields a blank page with silent 404s on JS/CSS — see
    Pitfall 2.
  - API calls will fail (no backend) but most SPAs degrade to "Loading…" / "No
    data" placeholders rather than crashing — this is still enough to show
    real layout, nav, filters, and branding.

### 4. Tour every page systematically
- Get an accessibility snapshot (`read_page`) to enumerate nav items. Hash-
  routed SPAs often use `<button>` nav elements, not `<a href>` — clicking
  isn't optional, and changing `location.hash` via `navigate_page` alone may
  **not** trigger the SPA's router (see Pitfall 3). Use `click_element` with
  the `ref` from the snapshot.
- If a click times out ("waiting for element to be visible, enabled and
  stable") but the element clearly exists, retry via
  `run_playwright_code` with `.click({ force: true })` — likely an overlay or
  animation is blocking the click target. If `force: true` "succeeds" but the
  page doesn't change, use `locator.dispatchEvent('click')` (see Pitfall 6).
- **Verify every navigation** before screenshotting: check `page.title()` or
  the active nav item. A silent no-op click produces N copies of the same page.
- Look for **sub-tabs inside pages** (segmented controls, toggles). They are
  often `div`s with `onClick`, not buttons, so they won't appear as
  `button` roles — read the component source to find them.
- Wait for data, not a fixed delay: poll until the main region no longer
  contains "Loading…" (live warehouse-backed apps can take 10-30 s per tab).
- For AI/chat pages (Genie, copilots), run **one aggregate, non-sensitive
  sample prompt** to show the feature working. Starter-prompt chips often
  only prefill the input — click Send afterward.
- Visit pages in the order the app's own nav presents them — that order is
  usually the intended user journey and makes a better narrative for the
  white paper.
- For heavy data tables, expect large accessibility-snapshot dumps (hundreds
  of KB) — that's fine, you don't need to read the whole thing; just confirm
  the page rendered and grab a screenshot.

### 5. Save real screenshots to disk
`screenshot_page` only *shows* an image inline — it does not persist a file.
To save screenshots for external use (reports, video pipelines, etc.), use
`run_playwright_code`:

```js
await page.screenshot({ path: 'C:\\abs\\path\\docs\\screenshots\\01-name.png', fullPage: true });
```

- Use `fullPage: true` so scrolled-off content is captured.
- Create the output directory first (`mkdir`/`New-Item`) before the first
  screenshot call.
- Number files in narrative order (`00-`, `01-`, `02-…`) so a downstream tool
  (slide deck, video storyboard) can consume them in sequence.
- Use descriptive kebab-case names: `04-ctbrfs-cover-sheet.png`.
- After saving, verify with a directory listing — don't assume the write
  succeeded silently. Spot-check at least one image with `view_image`,
  especially any that were masked.
- **Mask sensitive data before capture** (PHI/PII: names, SSN, ICN, DOB,
  emails). Blur the `tbody` of any table whose header matches identifying
  columns, then screenshot:

  ```js
  await page.evaluate(() => document.querySelectorAll('table').forEach(tb => {
    const h = (tb.querySelector('thead')?.innerText || '').toLowerCase();
    if (/patient name|patient icn|patient sid|\bssn\b|\bdob\b|email/.test(h)) tb.querySelector('tbody').style.filter = 'blur(6px)';
  }));
  ```

  Match identifier columns specifically — a loose `/patient/` also blurs
  aggregate tables with a "Unique Patients" count. State in the white paper
  and video script that masking was applied.
- Delete any stale/duplicate screenshots from failed passes you created, so
  the numbered sequence stays clean.

### 6. Write the white paper
Produce a single Markdown file (ask the user where — repo root is the default,
e.g. `WHITEPAPER.md`) with this structure:

1. **Title + metadata** — app name, prepared-for audience, live URL, primary
   data source, date. If documenting a live app that turned out to differ from
   local source, add an explicit **scope note** saying so.
2. **Executive Overview** — 1-2 paragraphs + a table of real headline
   metrics/KPIs pulled from the actual UI (never invent numbers).
3. **Who Uses It and Why** — table of audience → need → feature that meets it.
4. **Process/lifecycle diagram** (mermaid `flowchart`) if the app models a
   workflow (e.g. ticket/referral/claim lifecycle) — this is usually stated
   on the app's own landing page; reuse it.
5. **Functional Walkthrough** — one subsection per page/tab in nav order,
   describing what's shown and any non-obvious business logic observed in
   the source (data reconciliation, filters, calculated fields).
6. **Cross-cutting capabilities** — filters, exports, theming, roles/auth
   gating that apply across multiple pages.
7. **Security/Governance notes** — cite what the app itself states (auth
   model, audit logging, read-only guarantees) plus anything you observed in
   source (e.g. SQL parameterization, CORS config) worth flagging.
8. **Architecture** — mermaid diagram (client → app/backend → data store) plus
   prose on hosting, auth delegation, and deployment mechanism.
9. **Screenshots** — numbered list matching the saved files, one line each
   describing what it shows.
10. **Summary** — 3-ish bullet points on the app's core value proposition.

Keep claims grounded in what you actually read/saw — do not extrapolate
features that weren't observed in code or UI.

### 7. Create a video script when requested

When the user asks for a video script, use the completed white paper as the
source of truth and the screenshot index as the visual inventory. Do not repeat
the app-discovery tour unless the documentation is missing, stale, or conflicts
with the live app.

Default to a 5-6 minute executive product tour unless the user specifies a
different audience, length, or format. Save it beside the white paper as
`VIDEO-SCRIPT.md` and include:

1. **Production metadata** — audience, target duration, narration tone, and
  available visual assets.
2. **Production notes** — pacing, captions, transitions, sensitive-data
  masking, and accessibility considerations.
3. **Timed scenes** — continuous timestamps whose final time matches the stated
  target duration.
4. **Visual direction** — exact screenshot filenames or live-app actions,
  including what to pan, zoom, highlight, or animate.
5. **On-screen text** — brief phrases that support rather than duplicate the
  narration.
6. **Narration** — natural spoken prose with short sentences and clear
  transitions between scenes.
7. **Closing card** — product name, concise value proposition, and relevant
  platform attribution.

Use this default narrative arc when it fits the application:

1. Problem or mission
2. Product introduction and scale
3. Core user workflows
4. Differentiating capability
5. Architecture, performance, and governance
6. Outcome-focused close

Ground every metric in the live UI or white paper. If two sources disagree,
use the most recently verified source and avoid false precision. Never animate
features or results that were not observed; label illustrative sequences as
representative. Verify that every referenced asset exists and that scene
timestamps are continuous before finishing.

### 8. Render the video when requested

Producing the actual MP4 is a separate, reusable workflow. **Load the
[`narrated-demo-video`](../narrated-demo-video/SKILL.md) skill** instead of
improvising a pipeline. It bundles config-driven scripts
(`narrate.py`, `make_cards.py`, `build_video.py`) for neural narration,
word-timed captions, Ken Burns motion, cross-fades, title cards, and a
verification pass.

Handoff from this skill:

1. **Translate `VIDEO-SCRIPT.md` into `video/video.json`.** Each scene's
   narration becomes `narration`, its visual direction becomes `frames`, and
   its on-screen text becomes `titles` (offsets are relative to that scene's
   narration start). Spell out acronyms the TTS mispronounces in `speak`
   ("S Q L", "V A").
2. **Capture dedicated 16:9 frames into `video/frames/`** while you still have
   the authenticated browser session. The full-page white-paper PNGs upscale
   badly and are the wrong aspect ratio. Frame-capture recipe, sticky-nav and
   canvas-warm-up fixes are in that skill's step 2.
3. **Ask about the narration voice before generating it.** Neural TTS is a
   cloud call; offline Windows voices sound robotic and users notice.
4. **After rendering, update `VIDEO-SCRIPT.md` timestamps to match the render.**
   Scene length follows the real narration, so the final runtime rarely equals
   the script's estimate. Record the deviation rather than leaving stale times.

If the user only wants the script, stop at step 7.

## Pitfalls (learned the hard way)

1. **Local repo ≠ live deployed app.** A workspace can contain source for one
   app while the live URL the user cares about is a completely different,
   unrelated application (same hosting family, different product). Always
   verify the live app's title/branding before writing about it, and say so
   explicitly if there's a mismatch.
2. **Static build asset paths.** If `index.html` references `/static/assets/…`,
   serving the `static/` folder itself as webroot produces double-nested 404s
   (`/static/static/assets/…`). Serve the **parent** directory instead.
3. **Hash-routing needs real clicks.** `navigate_page` changing the URL hash
   does not reliably trigger client-side route changes in all SPAs — click the
   actual nav element (`click_element` with `ref`, or Playwright
   `getByRole('button', { name }).click({ force: true })` if blocked).
4. **Never authenticate on the user's behalf.** If a live app requires SSO
   login, pause and ask the user to complete it in the shared browser tab.
5. **`screenshot_page` is inline-only.** For files that must exist on disk
   (reports, video pipeline input), use `run_playwright_code` with
   `page.screenshot({ path, fullPage: true })`.
6. **`force: true` can silently miss.** With sticky headers/filter panels,
   a forced click may land on the overlay and not trigger React's handler —
   no error, no navigation. `locator.dispatchEvent('click')` fires the event
   directly on the target and works with React's delegated listeners.
7. **Live URL may only be in docs.** Deploy config (e.g. Databricks
   `app.yaml`) often omits the URL; grep the repo for the hosting domain
   (`databricksapps.com`, `azurewebsites.net`) — user guides and UAT plans
   usually list it.
8. **Video script numbers:** round in narration ("more than eight million"),
   keep exact values on screen only, and add a "figures as of <date/filter>"
   lower-third — live data changes after each refresh.
9. **Slow widgets don't appear in fast screenshots.** Canvas/WebGL panels
   (force graphs, live telemetry cores) can take 10–15 s to initialise and
   render blank or as a spinner in a quick capture. Wait for them to settle,
   or the white paper will under-describe the most visual part of the app.
10. **PII can hide inside the content itself.** Indexed documents, skill text,
    or search results can contain identifiers (SSNs, names) even when no table
    column is labelled as PII. Scan the rendered text for `\b\d{9}\b` and
    `\d{3}-\d{2}-\d{4}` before every capture, redact via a DOM text edit, and
    flag the source-level issue in the white paper's security section.
11. **Genie/chat answers can be confidently wrong.** Keep the generated SQL
    visible in screenshots, and cross-check any number Genie returns against
    the app's own UI before quoting it. A mismatch is itself worth documenting.
